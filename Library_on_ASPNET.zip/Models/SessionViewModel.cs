﻿using ASPLibrary.Data;
using static ASPLibrary.Data.BookDB;
using static ASPLibrary.Data.UserDB;

namespace ASPLibrary.Models
{
    public class SessionViewModel
    {
        public const String DefaultUser = "guest";
        private String m_user;

        public SessionViewModel(LibraryDB libraryDB) 
            : this(libraryDB, DefaultUser)
        {
        }

        public SessionViewModel(LibraryDB libraryDB, String user)
        {
            m_user = user ?? throw new ArgumentNullException(nameof(user));
            DB = libraryDB ?? throw new ArgumentNullException(nameof(libraryDB));
        }

        public LibraryDB DB { get; }

        public String User
        {
            get => m_user;
            set => m_user = value ?? DefaultUser;
        }

        public Guid AuthToken
        {
            get;
            set;
        }

        public Boolean IsLoggedIn
        {
            get => DB.Users.VerifyAuth(User, AuthToken);
        }

        public Boolean IsLibrarian
        {
            get => DB.Users.IsLibrarian(User);
        }

        public IEnumerable<Book> BooksView
        {
            get
            {
                if (BooksFilter == default)
                    return DB.Books.All;
                else
                    return DB.Books.All.Where(BooksFilter);
            }
        }

        public Func<Book, Boolean>? BooksFilter
        {
            get;
            set;
        }

        public SessionState State { get => IsLoggedIn ? SessionState.Normal : SessionState.NoAuth; }
    }

    public enum SessionState
    {
        NoAuth,
        Normal,
    }
}
