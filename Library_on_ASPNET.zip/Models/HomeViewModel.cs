﻿using ASPLibrary.Data;

namespace ASPLibrary.Models
{
    public class HomeViewModel : SessionViewModel
    {
        public HomeViewModel(LibraryDB libraryDB) : base(libraryDB)
        {
        }

        public HomeViewModel(LibraryDB libraryDB, String user) : base(libraryDB, user)
        {
        }


    }
}
