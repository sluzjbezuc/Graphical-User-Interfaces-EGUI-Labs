﻿using ASPLibrary.Data;
using Microsoft.AspNetCore.Mvc;

namespace ASPLibrary.Controllers
{
	public abstract class LibraryController : Controller
	{
		protected LibraryController()
			: this(LibraryDB.Default)
		{
		}

		protected LibraryController(LibraryDB dB)
		{
			DB = dB ?? throw new ArgumentNullException(nameof(dB));
		}

		protected Boolean IsSessionAuthorized()
		{
			return IsSessionAuthorized(out var _, out var _);
		}

		protected Boolean IsSessionAuthorized(out String user, out Guid auth)
		{
			user = String.Empty;
			auth = default;
			if (TempData.TryGetValue("user", out var _user))
			{
                if (TempData.TryGetValue("auth", out var _auth))
				{
					if (_user is String __user && _auth is Guid __auth)
					{
						user = __user;
						auth = __auth;
                        if (DB.Users.VerifyAuth(user, auth))
                        {
                            TempData.Keep("user");
                            TempData.Keep("auth");
                            return true;
						}
					}
				}
			}
			return false;
		}

		protected IActionResult GetAuthResponse(String user, Guid auth)
		{
			if (DB.Users.VerifyAuth(user, auth))
			{
				return Json(new { rsp = "okay" });
			}
			else
			{
				return Json(new { rsp = "fail", reason = "The username is invalid, or the auth token is expired" });
			}
		}

		protected IActionResult GetAuthResponse()
		{
			var reason = "Not authorized";
			if (TempData.TryGetValue("user", out var _user))
			{
				if (TempData.TryGetValue("auth", out var _auth))
				{
					if (_user is String user && _auth is Guid auth)
					{
						return GetAuthResponse(user, auth);
					}
					else reason = "Invalid session data";
				}
			}
			return Json(new { rsp = "fail", reason });
		}

		public LibraryDB DB { get; }
	}
}
