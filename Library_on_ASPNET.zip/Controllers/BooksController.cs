﻿using ASPLibrary.Data;
using Microsoft.AspNetCore.Mvc;

namespace ASPLibrary.Controllers
{
	public class BooksController : LibraryController
	{
		public IActionResult Index()
		{
			return View();
		}

        [HttpGet]
        public IActionResult TryReserve(Int32 bookID)
		{
            if (IsSessionAuthorized(out var user, out var _))
			{
				if (DB.Books.TryReserve(user, bookID))
				{
					return Json(new { rsp = "okay" });
				}
				return Json(new { rsp = "fail", reason = "The requested book is already reserved or leased" });
			}
			return GetAuthResponse();
		}

        [HttpGet]
        public IActionResult TryLease(Int32 bookID)
		{
			if (IsSessionAuthorized(out var user, out var _))
			{
				var reason = "You are not a librarian";
				if (DB.Users.IsLibrarian(user))
				{
					reason = "The requested book is already reserved or leased";
					if (DB.Books.TryLease(bookID))
						return Json(new { rsp = "okay" });
				}
				return Json(new { rsp = "fail", reason });
			}
			return GetAuthResponse();
		}

        [HttpGet]
        public IActionResult TryReturn(Int32 bookID)
        {
            if (IsSessionAuthorized(out var user, out var _))
            {
                var reason = "You are not a librarian";
                if (DB.Users.IsLibrarian(user))
                {
                    reason = "The requested book is already reserved or leased";
                    if (DB.Books.TryReturn(bookID))
                        return Json(new { rsp = "okay" });
                }
                return Json(new { rsp = "fail", reason });
            }
            return GetAuthResponse();
        }

        [HttpGet]
        public IActionResult TryCancel(Int32 bookID)
        {
            if (IsSessionAuthorized(out var user, out var _))
            {
                if (DB.Books.TryCancel(user, bookID))
                {
                    return Json(new { rsp = "okay" });
                }
                return Json(new { rsp = "fail", reason = "The requested book is already reserved or leased" });
            }
            return GetAuthResponse();
        }

        public BookDB Books { get; } = LibraryDB.Default.Books;
	}
}
