﻿using ASPLibrary.Data;
using Microsoft.AspNetCore.Mvc;

namespace ASPLibrary.Controllers
{
	public class UserController : LibraryController
	{
		public IActionResult Index()
		{
			return View();
		}

		[HttpGet]
		public IActionResult Login(String? user, String? pass)
		{
			if (user == default || pass == default)
                return Json(new { rsp = "fail", reason = "Invalid request" });
            if (IsSessionAuthorized())
				return Json(new { rsp = "fail", reason = "You are already logged in!" });
			if (DB.Users.TryAuthorize(user, pass, out var auth))
			{
				TempData["user"] = user;
				TempData["auth"] = auth; 
				TempData.Keep("user");
				TempData.Keep("auth");
                return GetAuthResponse();
            }
            var reason = "Database error";
            if (!DB.Users.All.Any(x => x.Name == user))
                reason = "Invalid username";
			else
                reason = "Invalid password";
            return Json(new { rsp = "fail", reason });
        }

        [HttpPost]
        public IActionResult Register(String? user, String? pass)
        {
            if (user == default || pass == default)
                return Json(new { rsp = "fail", reason = "Invalid request" });
            if (IsSessionAuthorized())
				return Json(new { rsp = "fail", reason = "You are already logged in!" });
			if (DB.Users.TryRegister(user, pass, out var auth))
			{
				TempData["user"] = user;
				TempData["auth"] = auth;
				TempData.Keep("user");
				TempData.Keep("auth");
				return GetAuthResponse();
			}
			var reason = "Database error";
			if (DB.Users.All.Any(x => x.Name == user))
                reason = "Account already exists";
            return Json(new { rsp = "fail", reason });
		}

        [HttpPost]
        public IActionResult LogOff()
		{
			if (IsSessionAuthorized(out var user, out var auth))
			{
				if (DB.Users.TryLogOff(user, auth))
				{
					TempData.Clear();
					return Json(new { rsp = "okay" });
				}
				return Json(new { rsp = "fail" });
			}
			return GetAuthResponse();
		}

        [HttpPost]
        public IActionResult Delete()
		{
			if (IsSessionAuthorized(out var user, out var _))
			{
				var reason = "User has one or more books leased/reserved";
				if (!DB.Books.All.Any(x => x.User == user))
				{
					if (DB.Users.IsLibrarian(user))
                        reason = "A librarian account can't be deleted";
                    else if (DB.Users.TryDelete(user))
                        return Json(new { rsp = "okay" });
                    else reason = "Database error";
                }
				return Json(new { rsp = "fail", reason });
			}
			return GetAuthResponse(); 
		}
	}
}
