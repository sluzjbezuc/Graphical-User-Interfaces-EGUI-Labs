﻿using ASPLibrary.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using System.Reflection;

namespace ASPLibrary.Controllers
{
	public class HomeController : LibraryController
	{
		private readonly ILogger<HomeController> _logger;

		public HomeController(ILogger<HomeController> logger)
		{
			_logger = logger;
		}

		public IActionResult Index()
		{
            return View(FetchModel());
		}

		protected HomeViewModel FetchModel()
		{
            var model = new HomeViewModel(DB);
            var user = TempData["user"] as String;
            if (user != default)
			{
                model.User = user;
                if (TempData["auth"] is Guid auth)
                {
					if (DB.Users.VerifyAuth(user, auth))
					{
                        model.AuthToken = auth;
                        TempData.Keep("auth");
                    }
					else
					{
						model.User = SessionViewModel.DefaultUser;
						model.AuthToken = default;
					}              
                }
				else model.User = SessionViewModel.DefaultUser;
            }
			return model;
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
		public IActionResult Error()
		{
			return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
		}
	}
}