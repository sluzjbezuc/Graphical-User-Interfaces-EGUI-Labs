﻿using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using static ASPLibrary.Data.UserDB;
using System.Globalization;

namespace ASPLibrary.Data
{
	public class BookDB
	{
		readonly Dictionary<Int32, Book> m_data;
		static readonly Object locker = new Object();

		public BookDB()
		{
			m_data = new();
		}

		protected void LoadUnlocked()
		{
            using (var file = File.OpenText("books.json"))
            using (var reader = new JsonTextReader(file))
            {
                var array = JObject.ReadFrom(reader) as JArray;
                if (array != null)
                {
                    foreach (JObject obj in array)
                    {
                        var book = Book.FromJson(obj);
                        m_data.Add(book.ID, book);
                    }
                }
            }
        }

		protected void SaveUnlocked()
		{
            var array = new JArray();
            foreach (var book in All)
                array.Add(Book.ToJson(book));
            File.WriteAllText("books.json", array.ToString(Formatting.Indented));
        }

		public void Load()
		{
			lock (locker)
			{
                LoadUnlocked();
            }
		}

		public void Save()
		{
			lock (locker)
			{
				SaveUnlocked();
            }
		}

		public Boolean TryReserve(String user, Int32 bookID)
		{
			lock (locker) 
			{
				var book = All.FirstOrDefault(x => x.ID == bookID);
				if (book == default || !book.IsAvailable)
					return false;
				book.User = user;
				var reservation = DateTime.UtcNow.Date;
				reservation.AddDays(1);
				reservation.AddHours(23);
				reservation.AddMinutes(59);
                book.Reserved = DateTime.UtcNow;
                SaveUnlocked();
                return true;
			}
		}

        public Boolean TryCancel(String user, Int32 bookID)
        {
            lock (locker)
            {
                var book = All.FirstOrDefault(x => x.ID == bookID);
                if (book == default || book.IsAvailable || book.User != user || book.Reserved == default)
                    return false;
				book.Reserved = default;
				book.User = default;
                SaveUnlocked();
                return true;
            }
        }

        public Boolean TryLease(Int32 bookID)
		{
			lock (locker)
			{
				var book = All.FirstOrDefault(x => x.ID == bookID);
				if (book == default || book.IsAvailable)
					return false;
				book.Leased = DateTime.UtcNow;
				book.Reserved = default;
                SaveUnlocked();
                return true;
			}
		}

        public Boolean TryReturn(Int32 bookID)
        {
            lock (locker)
            {
                var book = All.FirstOrDefault(x => x.ID == bookID);
                if (book == default || book.IsAvailable)
                    return false;
				book.Leased = default;
                book.Reserved = default;
                SaveUnlocked();
                return true;
            }
        }

        public IEnumerable<Book> All { get => m_data.Values; }

		public static BookDB Default { get; } = new();

		public class Book
		{
			public Book(Int32 id, Int32 date, String title, String author, String publisher)
			{
				ID = id;
				Year = date;
				Title = title ?? throw new ArgumentNullException(nameof(title));
				Author = author ?? throw new ArgumentNullException(nameof(author));
				Publisher = publisher ?? throw new ArgumentNullException(nameof(publisher));
			}

			public Int32 ID { get; private set; }
			public Int32 Year { get; private set; }
			public String Title { get; private set; }
			public String Author { get; private set; }
			public String Publisher { get; private set; }
			public String? User { get; set; }
			public DateTime? Leased { get; set; }
			public DateTime? Reserved { get; set; }
			public Boolean IsAvailable { get => Leased == default && Reserved == default; }

			public static Book FromJson(JObject json)
			{
				var id = (Int32?)json["id"];
				var date = (Int32?)json["date"];
				var title = (String?)json["title"];
				var author = (String?)json["author"];
				var publisher = (String?)json["publisher"];
				var user = (String?)json["user"];
				var leased = (String?)json["leased"];
				var reserved = (String?)json["reserved"];
				if (!id.HasValue
					|| !date.HasValue
					|| title == default
					|| author == default
					|| publisher == default
				) throw new InvalidDataException();
				else
				{
					var book = new Book(id.Value, date.Value, title, author, publisher)
					{
						User = user,
					};
					if (leased != default)
					{
                        if (DateTime.TryParse(leased, out var result))
						{
							book.Leased = result;
						}
                    }
					if (reserved != default)
                    {
                        if (DateTime.TryParse(reserved, out var result))
                        {
                            book.Reserved = result;
                        }
                    }
                    return book;
				}
			}

			public static JObject ToJson(Book book)
			{
				return new JObject()
				{
					{ "id", book.ID },
					{ "date", book.Year },
					{ "title", book.Title },
					{ "author", book.Author },
					{ "publisher", book.Publisher },
					{ "user", book.User ?? String.Empty },
					{ "leased", book.Leased?.ToString("d") ?? String.Empty },
					{ "reserved", book.Reserved?.ToString("d") ?? String.Empty },
				};
			}
		}
	}
}
