﻿using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using static ASPLibrary.Data.UserDB;

namespace ASPLibrary.Data
{
	public class UserDB 
	{
		readonly Dictionary<String, User> m_data;
		static readonly Object locker = new Object();

		public UserDB()
		{
			m_data = new();
		}

		protected void SaveUnlocked()
		{
            var array = new JArray();
            foreach (var account in All)
                array.Add(User.ToJson(account));
            File.WriteAllText("users.json", array.ToString(Formatting.Indented));
        }

		protected void LoadUnlocked()
		{
            using (var file = File.OpenText("users.json"))
            using (var reader = new JsonTextReader(file))
            {
                var array = JObject.ReadFrom(reader) as JArray;
                if (array != null)
                {
                    foreach (JObject obj in array)
                    {
                        var account = User.FromJson(obj);
                        m_data.Add(account.Name, account);
                    }
                }
            }
        }

		public void Load()
		{
			lock (locker)
			{
				LoadUnlocked();
            }
		}

		public void Save()
		{
			lock (locker)
			{
				SaveUnlocked();
            }
		}

		public Boolean IsLibrarian(String user)
		{
			// we can add a special table to check it here, or a field within the user class
			// if we ever wanted to have a different username but retain the privileges
			// this... this is simple but ugly, c'mon
			return user == "librarian";
		}
			
		public Boolean TryRegister(String user, String pass)
		{
			return TryRegister(user, pass, out var _);
        }

		public Boolean TryRegister(String user, String pass, out Guid? auth)
		{
			lock (locker)
			{
				if (!m_data.ContainsKey(user))
				{
					var account = new User(user, pass);
					auth = account.Auth = Guid.NewGuid();
					m_data.Add(user, account);
					SaveUnlocked();
					return true;
				}
				auth = default;
				return false;
			}
		}

		public Boolean TryAuthorize(String user, String pass, out Guid? auth)
		{
			lock (locker)
			{
				if (m_data.TryGetValue(user, out var account))
				{
					if (!account.IsAuthenticated && account.Pass == pass)
					{
						auth = account.Auth = Guid.NewGuid();
                        return true;
					}
				}
				auth = default;
				return false;
			}
		}

		public Boolean TryLogOff(String user, Guid auth)
		{
			lock (locker)
			{
				if (m_data.TryGetValue(user, out var account))
				{
					if (account.IsAuthenticated && account.Auth == auth)
					{
						account.Auth = default;
						return true;
					}
				}
				return false;
			}
		}

		public Boolean TryDelete(String user)
		{
			lock (locker)
			{
				if (m_data.TryGetValue(user, out var account))
				{
					if (m_data.Remove(user))
					{
                        SaveUnlocked();
						return true;
                    }
				}
				return false;
			}
		}

		public Boolean VerifyAuth(String user, Guid auth)
		{
			lock (locker)
			{
				if (m_data.TryGetValue(user, out var account))
				{
					if (account.IsAuthenticated && account.Auth == auth)
					{
						return true;
					}
				}
				return false;
			}
		}

		public IEnumerable<User> All { get => m_data.Values; }

		public static UserDB Default { get; } = new();

		public class User
		{
			public User(String name, String pass)
			{
				this.Name = name ?? throw new ArgumentNullException(nameof(name));
				this.Pass = pass ?? throw new ArgumentNullException(nameof(pass));
			}

			public String Name { get; private set; }
			public String Pass { get; private set; }

			public Guid? Auth { get; set; }
			public Boolean IsAuthenticated { get => Auth != null; }

			public static User FromJson(JObject json)
			{
				var user = (String?)json["user"];
				var pass = (String?)json["pwd"];
				if (user == default || pass == default)
					throw new InvalidDataException();
				else return new User((String)user, (String)pass);
			}

			public static JObject ToJson(User account)
			{
				return new JObject()
				{
					{ "user", account.Name },
					{ "pwd", account.Pass },
				};
			}
		}
	}
}
