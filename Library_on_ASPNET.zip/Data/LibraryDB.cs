﻿namespace ASPLibrary.Data
{
	public class LibraryDB
	{
		public LibraryDB(UserDB users, BookDB books)
		{
			Users = users ?? throw new ArgumentNullException(nameof(users));
			Books = books ?? throw new ArgumentNullException(nameof(books));
		}

		public void Load()
		{
			Users.Load();
            Books.Load();
        }

        public void Save()
        {
            Users.Load();
            Books.Load();
        }

        public UserDB Users { get; }
		public BookDB Books { get; }

		public static LibraryDB Default { get; }
			= new LibraryDB(UserDB.Default, BookDB.Default);
	}
}
